from enum import IntEnum

class SpritePackingMode(IntEnum):
    kSPMTight = 0
    kSPMRectangle = 1