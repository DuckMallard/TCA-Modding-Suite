from enum import IntEnum


class PassType(IntEnum):
    kPassTypeNormal = 0
    kPassTypeUse = 1
    kPassTypeGrab = 2
